const list = document.getElementById("jobs");
const savedList = document.getElementById("saved-jobs");
const search = document.getElementById("search");
const message = document.getElementById("message");

function jobText(job) {
  return `${job.title} at ${job.company}, ${job.location}. Rs ${Number(job.stipend).toLocaleString("en-IN")} a month.`;
}

async function request(url, options) {
  const response = await fetch(url, options);
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || "Request failed");
  return data;
}

async function showJobs(query = "") {
  const jobs = await request(`/api/jobs?q=${encodeURIComponent(query)}`);
  list.replaceChildren();
  for (const job of jobs) {
    const li = document.createElement("li");
    const description = document.createElement("div");
    description.textContent = jobText(job);
    const button = document.createElement("button");
    button.textContent = "Save job";
    button.addEventListener("click", async () => {
      try { await request("/api/saved-jobs", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ id: job.id }) }); message.textContent = "Job saved."; await showSavedJobs(); }
      catch (error) { message.textContent = error.message; }
    });
    li.append(description, button);
    list.append(li);
  }
}

async function showSavedJobs() {
  const jobs = await request("/api/saved-jobs");
  savedList.replaceChildren();
  for (const job of jobs) {
    const li = document.createElement("li");
    const description = document.createElement("div");
    description.textContent = jobText(job);
    const button = document.createElement("button");
    button.textContent = "Remove";
    button.addEventListener("click", async () => {
      try { await request(`/api/saved-jobs/${encodeURIComponent(job.id)}`, { method: "DELETE" }); message.textContent = "Job removed."; await showSavedJobs(); }
      catch (error) { message.textContent = error.message; }
    });
    li.append(description, button);
    savedList.append(li);
  }
  if (!jobs.length) savedList.innerHTML = '<li class="muted">No saved jobs yet.</li>';
}

search.addEventListener("input", () => showJobs(search.value).catch((error) => { message.textContent = error.message; }));
showJobs().catch((error) => { message.textContent = error.message; });
showSavedJobs().catch((error) => { message.textContent = error.message; });
