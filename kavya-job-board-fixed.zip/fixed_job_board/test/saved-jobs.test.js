import { test } from "node:test";
import assert from "node:assert/strict";
import { createApp } from "../server.js";

async function withServer(run) {
  const server = createApp();
  await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
  const base = `http://127.0.0.1:${server.address().port}`;
  try { await run(base); } finally { await new Promise((resolve, reject) => server.close((err) => err ? reject(err) : resolve())); }
}

test("saved jobs can be added, listed and removed", async () => {
  await withServer(async (base) => {
    let response = await fetch(`${base}/api/saved-jobs`);
    assert.deepEqual(await response.json(), []);

    response = await fetch(`${base}/api/saved-jobs`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ id: "j2" }) });
    assert.equal(response.status, 201);

    response = await fetch(`${base}/api/saved-jobs`);
    const saved = await response.json();
    assert.equal(saved.length, 1);
    assert.equal(saved[0].id, "j2");

    response = await fetch(`${base}/api/saved-jobs/j2`, { method: "DELETE" });
    assert.equal(response.status, 200);
    response = await fetch(`${base}/api/saved-jobs`);
    assert.deepEqual(await response.json(), []);
  });
});

test("cannot save an unknown job", async () => {
  await withServer(async (base) => {
    const response = await fetch(`${base}/api/saved-jobs`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ id: "missing" }) });
    assert.equal(response.status, 404);
  });
});
