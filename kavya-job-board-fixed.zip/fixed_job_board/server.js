// A small job board with job search and saved jobs. Run with `npm start`.
import { createServer } from "node:http";
import { readFile } from "node:fs/promises";
import { pathToFileURL } from "node:url";
import { loadJobs, searchJobs, findJob } from "./lib/jobs.js";

const PORT = Number(process.env.PORT ?? 3000);

function sendJson(res, status, body) {
  res.writeHead(status, { "content-type": "application/json; charset=utf-8" });
  res.end(JSON.stringify(body));
}

async function readJson(req) {
  let body = "";
  for await (const chunk of req) body += chunk;
  try { return JSON.parse(body || "{}"); }
  catch { return null; }
}

export function createApp() {
  // Saved IDs are held in memory for this running server instance.
  const savedIds = new Set();
  return createServer(async (req, res) => {
    try {
      const url = new URL(req.url ?? "/", "http://localhost");
      if (req.method === "GET" && url.pathname === "/api/jobs") {
        const jobs = await loadJobs();
        return sendJson(res, 200, searchJobs(jobs, url.searchParams.get("q")));
      }
      if (url.pathname === "/api/saved-jobs" && req.method === "GET") {
        const jobs = await loadJobs();
        return sendJson(res, 200, [...savedIds].map((id) => findJob(jobs, id)).filter(Boolean));
      }
      if (url.pathname === "/api/saved-jobs" && req.method === "POST") {
        const body = await readJson(req);
        if (!body || typeof body.id !== "string") return sendJson(res, 400, { error: "A job id is required" });
        const jobs = await loadJobs();
        if (!findJob(jobs, body.id)) return sendJson(res, 404, { error: "Job not found" });
        savedIds.add(body.id);
        return sendJson(res, 201, { saved: true, id: body.id });
      }
      const savedMatch = url.pathname.match(/^\/api\/saved-jobs\/([^/]+)$/);
      if (savedMatch && req.method === "DELETE") {
        const id = decodeURIComponent(savedMatch[1]);
        const existed = savedIds.delete(id);
        return existed ? sendJson(res, 200, { removed: true, id }) : sendJson(res, 404, { error: "Saved job not found" });
      }
      if (req.method === "GET" && (url.pathname === "/" || url.pathname === "/app.js")) {
        const file = url.pathname === "/" ? "index.html" : "app.js";
        const type = file.endsWith(".html") ? "text/html" : "text/javascript";
        const body = await readFile(new URL(`./public/${file}`, import.meta.url));
        res.writeHead(200, { "content-type": `${type}; charset=utf-8` });
        return res.end(body);
      }
      sendJson(res, 404, { error: "Not found" });
    } catch (err) {
      console.error(err);
      sendJson(res, 500, { error: "Something went wrong" });
    }
  });
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  createApp().listen(PORT, () => console.log(`Job board on http://localhost:${PORT}`));
}
