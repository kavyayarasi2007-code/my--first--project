# Job board

A small job board for an insiderOne work sample. The jobs and companies are fictional.

## Requirements

- Node.js 20 or newer
- No third-party packages are required

## Run it

```sh
npm start
```

Then open http://localhost:3000 in your browser.

Run the automated tests with:

```sh
npm test
```

## Project structure

- `server.js`: HTTP server and JSON API.
- `lib/jobs.js`: loading, searching and finding jobs.
- `jobs.json`: the eight sample jobs.
- `public/index.html`: the job board page.
- `public/app.js`: browser-side search and saved-job interactions.
- `test/`: automated tests using Node's built-in test runner.

## What I built

The job board lists jobs and supports searching by title, company or location. Users can save a job, view their saved jobs, and remove a saved job. The saved-job API validates job IDs and returns clear error responses for unknown jobs. Saved jobs are held in server memory, so they reset when the server restarts.
